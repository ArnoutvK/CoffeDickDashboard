function confirm() {
    if (window.confirm("Do you want to cancel your changes?")) {
        window.location.href = "/bots.html";
    }
}